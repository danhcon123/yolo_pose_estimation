# key points > 2025-04-03 1:49pm
https://universe.roboflow.com/test-l1beo/key-points-lvkij

Provided by a Roboflow user
License: CC BY 4.0

